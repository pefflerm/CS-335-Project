/**
 * 
 */
/**
 * 
 */
module roamnroot_project {
	requires java.desktop;
	requires com.opencsv;
}