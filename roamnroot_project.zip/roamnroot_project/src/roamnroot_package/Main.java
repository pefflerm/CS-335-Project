package roamnroot_package;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String t = "yes";  // Variable to control the outer loop
        String s = "yes";  // Variable to control category selection
        Menu menu = new Menu();  // Correct class name (capital 'M')

        // Start the menu interaction (assumes menu.menu(sc) is an instance method)
        String selectedOption = menu.menu(sc);  // Correct scanner variable
        System.out.println("You selected: " + selectedOption);

        // Main loop to allow category navigation
        while (t.equalsIgnoreCase("yes")) {
            s = menu.menu(sc);  // Get the user's menu selection

            if (s == null || s.isEmpty()) {
                System.out.println("Invalid selection. Please try again.");
                continue;
            }

            // Handle "Go Back" selections
            while (s.equalsIgnoreCase("Go Back")) {
                s = menu.menu(sc);  // Re-prompt for selection
            }

            // Get the corresponding CSV file for the selected category
            String csvFile = getCsvFile(s);
            if (csvFile.isEmpty()) {
                System.out.println("No data available for the selected category.");
                continue;  // Skip if no data is available
            }

            // Create a Placesfactory instance for data processing
            Placesfactory df = new Placesfactory("places/" + csvFile);
            System.out.println("\n--- " + s.toUpperCase() + " ---");

            // Assuming Placesfactory's getHeaders() returns a CSV row string for headers
            String[] firstRow = df.getHeaders().split(",");

            // Loop through places' data in the selected category's CSV file
            while (df.moreData()) {
                ArrayList<String> placeDetails = df.getNextPlace();

                // Display place details
                for (int i = 0; i < firstRow.length && i < placeDetails.size(); i++) {
                    System.out.println(firstRow[i].trim() + ": " + placeDetails.get(i));
                }

                System.out.println("----------------------");

                // Ask if the user wants to leave a review
                System.out.print("Would you like to leave a review for this place? (yes/no): ");
                String leaveReview = sc.nextLine().trim().toLowerCase();

                // If yes, ask for rating and a text review
                if (leaveReview.equals("yes")) {
                    int rating = getRating(sc);
                    System.out.print("Enter your review: ");
                    String reviewText = sc.nextLine().trim();
                    System.out.println("Thank you for your review!");

                    // Optionally store or display the review, here we just print it
                    System.out.println("Your review: " + rating + " stars");
                    System.out.println("Review: " + reviewText);
                }

                // Ask the user if they want to see the next place or stop
                System.out.print("Type 'Next' to see the next place or 'Exit' to stop: ");
                String input = sc.nextLine().trim().toLowerCase();  // Convert input to lowercase to avoid case issues

                // Loop until user types "next" or "exit"
                while (!input.equals("next") && !input.equals("exit")) {
                    // Just keep asking the user without showing the "Invalid input" message
                    input = sc.nextLine().trim().toLowerCase();  // Keep reading until "Next" or "Exit" is typed
                }

                if (input.equals("exit")) {
                    break; // Exit the loop if the user types 'Exit'
                }
            }

            // Ask if the user wants to explore other categories
            System.out.print("Would you like to check out other categories? (yes/no): ");
            t = sc.nextLine().trim();
        }

        sc.close();  // Properly close the scanner after use
        System.out.println("Thank you for using the program!");
    }

    // Method to get the corresponding CSV file for a selected category
    private static String getCsvFile(String category) {
        switch (category) {
            case "Night Out": return "Copy of Boston Recommendations  - Going out Bars.csv";
            case "Brunch": return "Boston Recommendations  - Brunch.csv";
            case "Cafes/Bakeries": return "Copy of Boston Recommendations  - Coffee Shops _ Bakery.csv";
            case "Lunch/Dinner": return "Copy of Boston Recommendations  - Restaurants.csv";
            case "Shopping": return "Copy of Boston Recommendations  - Shopping.csv";
            case "Fun Activities": return "Copy of Boston Recommendations  - Things To Do.csv";
            case "Outdoors": return "Copy of Boston Recommendations  - Summer _ Outdoor.csv";
            case "Spa":
            case "Skincare/Haircare":
            case "Massage":
                return "Copy of Boston Recommendations  - Spa_Beauty.csv";
            default:
                return "";
        }
    }

    // Method to get a valid star rating (1-5)
    private static int getRating(Scanner sc) {
        int rating;
        while (true) {
            System.out.print("Enter your rating (1-5 stars): ");
            if (sc.hasNextInt()) {
                rating = sc.nextInt();
                sc.nextLine();  // Consume the newline character
                if (rating >= 1 && rating <= 5) {
                    return rating;
                } else {
                    System.out.println("Please enter a rating between 1 and 5.");
                }
            } else {
                sc.next(); // Consume the invalid input
                System.out.println("Invalid input! Please enter a number between 1 and 5.");
            }
        }
    }
}
