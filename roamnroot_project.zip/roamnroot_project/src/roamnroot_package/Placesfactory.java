import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Placesfactory { 
    private Scanner sc;
    private File placeFile;
    private String firstRow;
   

   
    public Placesfactory() {
        sc = new Scanner(System.in);
    }


    public Placesfactory(String source) {
        try {
            placeFile = new File(source);
            sc = new Scanner(placeFile);
            if (sc.hasNextLine()) {
<<<<<<< HEAD:Placesfactory.java
               firstRow = sc.nextLine(); // Read the first row
                System.out.println("First row: " + firstRow);
=======
                firstRow = sc.nextLine(); // Read the first row (headers)
>>>>>>> a650cac (Sprint 2):src/roamnroot_package/Placesfactory.java
            }
            
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred. Enter info from keyboard.");
            e.printStackTrace();
            sc = new Scanner(System.in); // Fallback to user input
        }
    }

    public boolean moreData() {
        return sc.hasNextLine();
    }

<<<<<<< HEAD:Placesfactory.java
    
    public ArrayList<String> getNextPlace() {
        ArrayList<String> placeDetails = new ArrayList<>();

=======
    // Get the next place from the file (starting from the 3rd line)
    public Location getNextPlace() {
    	Location place;
>>>>>>> a650cac (Sprint 2):src/roamnroot_package/Placesfactory.java
        if (sc.hasNextLine()) {
            String data = sc.nextLine();
            String[] arrOfStr = data.split(",", 10); 

            //for (String value : arrOfStr) {
                //placeDetails.add(value.trim()); // Add to list after trimming spaces
            //}
            place = new Location(arrOfStr[0], arrOfStr[1]);
        }else {
        	place = new Location("None","None");
        }
		return place;
    }
    public String getHeaders() {
        return(firstRow);
    }
}
