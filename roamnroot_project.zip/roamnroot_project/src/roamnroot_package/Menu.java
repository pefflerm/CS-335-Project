package roamnroot_package;
import java.util.*;

public class Menu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        menu(scanner);
        scanner.close();
    }

    public static String menu(Scanner scanner) {
        int choice;
        String selectedOption = "";

        while (true) {
            System.out.println("\nWELCOME TO ROAM N' ROOT");
            System.out.println("\n===== MENU =====");
            System.out.println("1. Restaurants");
            System.out.println("2. Things to Do");
            System.out.println("3. Self-Care");
            System.out.println("4. Add a New Location");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            choice = getValidChoice(scanner, 5);

            switch (choice) {
                case 1:
                    selectedOption = restaurantMenu(scanner);
                    break;
                case 2:
                    selectedOption = activitiesMenu(scanner);
                    break;
                case 3:
                    selectedOption = selfCareMenu(scanner);
                    break;
                case 4:
                    selectedOption = newLocationMenu(scanner); // Updated method call
                    break;
                case 5:
                    System.out.println("Exiting... Goodbye!");
                    break;
                default:
                    break;
            }

            // If we have selected a valid option, return it
            if (!selectedOption.isEmpty()) {
                return selectedOption;
            }
        }
    }

    private static String restaurantMenu(Scanner scanner) {
        System.out.println("\n===== Restaurant Types =====");
        System.out.println("1. Night Out");
        System.out.println("2. Brunch");
        System.out.println("3. Cafes/Bakeries/Study Friendly");
        System.out.println("4. Lunch/Dinner");
        System.out.println("5. Go Back");
        System.out.print("Enter your choice: ");

        int subChoice = getValidChoice(scanner, 5);
        return getRestaurantType(subChoice);
    }

    private static String activitiesMenu(Scanner scanner) {
        System.out.println("\n===== Things to Do =====");
        System.out.println("1. Shopping");
        System.out.println("2. Fun Activities");
        System.out.println("3. Outdoors");
        System.out.println("4. Go Back");
        System.out.print("Enter your choice: ");

        int subChoice = getValidChoice(scanner, 4);
        return getActivityType(subChoice);
    }

    private static String selfCareMenu(Scanner scanner) {
        System.out.println("\n===== Self-Care Activities =====");
        System.out.println("1. Spa");
        System.out.println("2. Massage");
        System.out.println("3. Skincare/Haircare");
        System.out.println("4. Go Back");
        System.out.print("Enter your choice: ");

        int subChoice = getValidChoice(scanner, 4); // Corrected to 4 options
        return getSelfCareType(subChoice);
    }

    private static String newLocationMenu(Scanner scanner) {
        // Option to add a new location
        System.out.println("\n===== Add a New Location =====");
        LocationFactory locationFactory = new LocationFactory("newlocationplace.csv");
        locationFactory.addNewLocation();  // Call the addNewLocation method to add data
        return ""; // Returning empty string to stay within the menu loop
    }

    private static int getValidChoice(Scanner scanner, int maxOption) {
        int choice;
        while (true) {
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                if (choice >= 1 && choice <= maxOption) {
                    return choice;
                }
            } else {
                scanner.next();
            }
            System.out.print("Invalid input! Please enter a number between 1 and " + maxOption + ": ");
        }
    }

    private static String getRestaurantType(int choice) {
        switch (choice) {
            case 1: return "Night Out";
            case 2: return "Brunch";
            case 3: return "Cafes/Bakeries";
            case 4: return "Lunch/Dinner";
            case 5: return "Go Back";
            default: return ""; 
        }
    }

    private static String getActivityType(int choice) {
        switch (choice) {
            case 1: return "Shopping";
            case 2: return "Fun Activities";
            case 3: return "Outdoors";
            case 4: return "Go Back";
            default: return ""; 
        }
    }

    private static String getSelfCareType(int choice) {
        switch (choice) {
            case 1: return "Spa";
            case 2: return "Massage";
            case 3: return "Skincare/Haircare";
            case 4: return "Go Back";
            default: return ""; 
        }
    }
}


